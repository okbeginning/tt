# shanbay_remember
扇贝自动发送今日新词到 telegram

## steps
1. Get your telegram token and chatid (please google how to)
2. Get your shanbay cookie from webbrower
3. Change the secrets to your own

![image](https://user-images.githubusercontent.com/15976103/100818317-d6436300-3484-11eb-945d-8c5fb72f4ce4.png)
![image](https://user-images.githubusercontent.com/15976103/100818363-f07d4100-3484-11eb-9d4c-23d4182ad4af.png)
